const form = document.querySelector("form")
const tema = form.querySelector("#tema")
console.log(tema.value)