let idade = "18"
if(idade == 18){
	console.log("Maior de idade")
}
console.log(`Idade: ${idade}`)